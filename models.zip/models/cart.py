from . import db,u
cart_products = db.Table('cart_products',
                            db.Column('id',db.Integer,primary_key=True),
                            db.Column('cart_id', db.Integer, db.ForeignKey('roles.id'), primary_key=True),
                            db.Column('product_id', db.Integer, db.ForeignKey('permissions.id'), primary_key=True)
                            )
class Carts(db.Model):
    __tablename__ = 'carts'
    id = db.Column(db.Integer,primary_key=True)
    name= db.Column(db.String(100))

class CartProducts(db.Model):
    id = db.Column(db.Integer,primary_key=True)
    amount = db.Column(db.Integer)
    product_id = db.Column(db.Integer,db.ForeignKey('products.id'))
    cart_id = db.Column(db.Integer,db.ForeignKey('carts.id'))